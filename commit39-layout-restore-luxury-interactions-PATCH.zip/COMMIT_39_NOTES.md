Commit 39 Patch

Purpose:
- Removes broad Commit 38 global typography overrides that caused clipping and low contrast.
- Restores layout-safe typography with targeted dark/light section rules.
- Adds subtle luxury interaction polish for hamburger, mobile menu, gemstone buttons, and cards.

Install:
- Replace the current style.css with this patched style.css.
- Deploy and verify homepage + Payments/Donations page on mobile.
